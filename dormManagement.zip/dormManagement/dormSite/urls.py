from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('register-student/', views.register_student, name='register_student'),
    path('student-stat/', views.student_stat, name='student_stat'),
    path('student-edit/', views.student_edit, name='student_edit'),
    path('student-edit/<str:student_id>',
         views.student_edit, name='student_edit'),
    path('dorm-stat/', views.dorm_stat, name='dorm_stat'),
    path('dorm-edit/', views.dorm_edit, name='dorm_edit'),
    path('dorm-edit/<int:room_no>', views.dorm_edit, name='dorm_edit'),
    path('export-excel/', views.export_excel, name='export_excel'),
]
