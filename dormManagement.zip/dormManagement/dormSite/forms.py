from dataclasses import field
from django import forms
from .models import *


class LoginForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('username', 'password')
        widgets = {
            'password': forms.PasswordInput
        }


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = "__all__"
        widgets = {
            "dob": forms.DateInput(attrs={"type": "date"}),
            "date_of_enrolment": forms.DateInput(attrs={"type": "date"}),
        }


class DormForm(forms.ModelForm):
    class Meta:
        model = Dormitory
        fields = "__all__"
