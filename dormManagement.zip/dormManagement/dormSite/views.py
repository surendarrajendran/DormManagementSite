from datetime import datetime
import xlwt

from django.shortcuts import render
from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from django.contrib.postgres.search import SearchVector

from .models import *
from .forms import *


def index(request):
    if request.method == "POST":
        login_form = LoginForm(request.POST)
        if login_form.is_valid():
            form_data = login_form.cleaned_data

            try:
                User.objects.get(
                    username=form_data["username"], password=form_data["password"])
                # return JsonResponse(form_data)
                return HttpResponseRedirect("/dashboard")
            except:
                return HttpResponse("Username or Password is incorrect. <a href='/'>Try Again</a>")

    else:
        login_form = LoginForm()

    return render(request, 'dormSite/index.html', {"login_form": login_form})


def dashboard(request):
    return render(request, 'dormSite/dashboard.html')


def register_student(request):
    if request.method == "POST":
        reg_form = StudentForm(request.POST)
        if reg_form.is_valid():
            form_data = reg_form.cleaned_data

            try:
                reg_form.save()
                return HttpResponseRedirect("/dashboard")
            except:
                return HttpResponse("Student Registration Unsuccessful. <a href='/register-student'>Try Again</a>")
    else:
        reg_form = StudentForm()

    return render(request, 'dormSite/register_stud.html', {"reg_form": reg_form})


def student_stat(request):
    if request.method == "POST":
        search_term = request.POST["stud_search"]
        search_results = student_search_db(search_term)
        if search_results.count() == 0:
            return render(request, 'dormSite/student_stat.html', {'no_students': True})
        else:
            return render(request, 'dormSite/student_stat.html', {"all_students": search_results, "search_term": search_term})

    all_students = Student.objects.all()
    return render(request, 'dormSite/student_stat.html', {'all_students': all_students})


def student_search_db(search_term: str):
    id_search_results = Student.objects.filter(student_id=search_term)
    first_name_search_results = Student.objects.filter(
        first_name=search_term)
    last_name_search_results = Student.objects.filter(
        last_name=search_term)
    search_results = id_search_results | first_name_search_results | last_name_search_results
    return search_results


def export_excel(request):
    table_names_models = {
        "student": Student,
        "room": Dormitory
    }
    table_name = request.POST["table_name"]
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = f"attachment; filename={table_name.capitalize()}_data_{str(datetime.now())}.xls"

    search_term = request.POST["search_term"]

    workbook = xlwt.Workbook(encoding="utf-8")
    worksheet = workbook.add_sheet(f"{table_name.capitalize()} Data")
    row_num = 0
    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    # Setting header row
    columns = [
        field.name for field in table_names_models[table_name]._meta.get_fields()]
    for (col_num, col_name) in enumerate(columns):
        worksheet.write(row_num, col_num, col_name, font_style)

    font_style = xlwt.XFStyle()

    if search_term:
        if table_name == "student":
            rows = student_search_db(search_term).values_list(*columns)
        elif table_name == "room":
            pass
    else:
        rows = table_names_models[table_name].objects.all(
        ).values_list(*columns)

    for row in rows:
        row_num += 1

        for col_num in range(len(columns)):
            worksheet.write(row_num, col_num, str(row[col_num]), font_style)

    workbook.save(response)

    return response


def student_edit(request, student_id):
    current_details = Student.objects.get(student_id=student_id)

    if request.method == "POST":
        stud_edit_form = StudentForm(request.POST, instance=current_details)

        if stud_edit_form.is_valid():

            try:
                stud_edit_form.save()
                return render(request, 'dormSite/student_edit.html', {'stud_form': stud_edit_form, "student_id": student_id, 'msg': True})
            except:
                return HttpResponse("Student Detail Updating Unsuccessful. <a href='/student-stat'>Try Again</a>")
        else:
            return HttpResponse(stud_edit_form.errors)

    stud_edit_form = StudentForm(instance=current_details)

    return render(request, 'dormSite/student_edit.html', {'stud_form': stud_edit_form, "student_id": student_id})


def dorm_stat(request):
    all_rooms = Dormitory.objects.all()
    if request.method == "POST":
        search_term = request.POST["dorm_search"]
        search_results = dorm_search_db(search_term)
        if search_results.count() == 0:
            return render(request, 'dormSite/dorm_stat.html', {"all_rooms": search_results, "search_term": search_term})
        else:
            return render(request, 'dormSite/dorm_stat.html', {"all_rooms": search_results, "search_term": search_term})

    return render(request, 'dormSite/dorm_stat.html', {'all_rooms': all_rooms})


def dorm_search_db(search_term: str):
    if search_term.isnumeric():
        room_num_search_res = Dormitory.objects.filter(room_no=search_term)
    else:
        room_num_search_res = Dormitory.objects.filter(room_no=99999999)
    room_type_search_res = Dormitory.objects.filter(
        room_type=search_term)

    if search_term.lower() in ["true", "false"]:
        room_avail_search_res = Dormitory.objects.filter(
            room_availability=search_term)

        search_results = room_num_search_res | room_type_search_res | room_avail_search_res
        return search_results

    search_results = room_num_search_res | room_type_search_res
    return search_results


def dorm_edit(request, room_no):
    current_details = Dormitory.objects.get(room_no=room_no)

    if request.method == "POST":
        room_edit_form = DormForm(request.POST, instance=current_details)

        if room_edit_form.is_valid():

            try:
                room_edit_form.save()
                return render(request, 'dormSite/dorm_edit.html', {'room_form': room_edit_form, "room_no": room_no, 'msg': True})
            except Exception as e:
                print(e)
                return HttpResponse("Student Detail Updating Unsuccessful. <a href='/dorm-stat'>Try Again</a>")
        else:
            return HttpResponse(room_edit_form.errors)

    room_edit_form = DormForm(instance=current_details)

    return render(request, 'dormSite/dorm_edit.html', {'room_form': room_edit_form, "room_no": room_no})
