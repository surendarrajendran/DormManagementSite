from django.db import models

# Create your models here.


class Dormitory(models.Model):
    room_no = models.IntegerField(primary_key=True)
    room_choices = [
        ('SS', "Single Shared"),
        ('DS', "Double Shared")
    ]
    room_type = models.CharField(
        max_length=2, choices=room_choices, default="SS")
    room_avail_choice = [
        (True, "Yes"),
        (False, "No")
    ]
    room_availability = models.BooleanField(choices=room_avail_choice)

    def __str__(self) -> str:
        return f"{self.room_no}-{self.room_type}"


class Student(models.Model):
    student_id = models.CharField(max_length=20, primary_key=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    dob = models.DateField()
    email_id = models.EmailField()
    citizenship = models.CharField(max_length=50)
    date_of_enrolment = models.DateField()
    registered_university = models.CharField(max_length=100)
    room_choices = [
        ('SS', "Single Shared"),
        ('DS', "Double Shared")
    ]
    room_type = models.CharField(
        max_length=2, choices=room_choices, default="SS")
    room_number = models.ForeignKey('Dormitory', on_delete=models.CASCADE)
    gym_choices = [
        (True, "Yes"),
        (False, "No")
    ]
    gym_access = models.BooleanField(choices=gym_choices, default=False)

    def __str__(self) -> str:
        return f"{self.student_id} - {self.first_name} {self.last_name}"


class User(models.Model):
    user_id = models.CharField(max_length=20, primary_key=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    dob = models.DateField()
    email_id = models.EmailField()
    citizenship = models.CharField(max_length=50)
    date_of_enrolment = models.DateField()
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

    def __str__(self) -> str:
        return f"{self.user_id} - {self.username}"
